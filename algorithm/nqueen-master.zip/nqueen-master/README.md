My exploration of the N Queen Puzzle

Author
=====

SJ Zhu @ USTC
